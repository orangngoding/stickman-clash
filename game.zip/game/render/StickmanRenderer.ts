import { SKELETON } from "../constants";
import { clamp } from "../core/math";
import type { Skeleton } from "./Skeleton";
import type { Vec2 } from "../types";

export interface StickmanStyle {
  body: string;
  accent: string;
  /** Warna anggota badan yang jauh dari kamera (lebih gelap agar terasa ada kedalaman). */
  far: string;
}

/** Menggambar stickman hanya dari garis dan lingkaran. Tidak ada sprite (GDD Bagian 8). */
export class StickmanRenderer {
  draw(ctx: CanvasRenderingContext2D, skeleton: Skeleton, style: StickmanStyle, frame: number): void {
    const j = skeleton.joints;

    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = SKELETON.lineWidth;

    // Urutan gambar: sisi jauh, torso, sisi dekat, kepala.
    ctx.strokeStyle = style.far;
    this.chain(ctx, j.shoulder, j.elbowL, j.handL);
    this.chain(ctx, j.hip, j.kneeL, j.footL);

    ctx.strokeStyle = style.body;
    this.chain(ctx, j.hip, j.neck);
    this.chain(ctx, j.hip, j.kneeR, j.footR);

    // Kepala
    ctx.fillStyle = style.body;
    ctx.beginPath();
    ctx.arc(j.head.x, j.head.y, SKELETON.headRadius, 0, Math.PI * 2);
    ctx.fill();

    this.drawHeadband(ctx, skeleton, style, frame);

    ctx.strokeStyle = style.body;
    this.chain(ctx, j.shoulder, j.elbowR, j.handR);
  }

  /** Bayangan lonjong di lantai, mengecil dan memudar saat fighter melayang. */
  drawShadow(ctx: CanvasRenderingContext2D, x: number, floorY: number, heightAboveFloor: number): void {
    const shrink = 1 - clamp(heightAboveFloor / 320, 0, 0.6);
    ctx.fillStyle = `rgba(0, 0, 0, ${0.35 * shrink})`;
    ctx.beginPath();
    ctx.ellipse(x, floorY + 2, 36 * shrink, 7 * shrink, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  private chain(ctx: CanvasRenderingContext2D, ...points: Vec2[]): void {
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
    ctx.stroke();
  }

  /** Ikat kepala berwarna aksen dengan dua ekor yang berkibar pelan. */
  private drawHeadband(
    ctx: CanvasRenderingContext2D,
    skeleton: Skeleton,
    style: StickmanStyle,
    frame: number,
  ): void {
    const { head } = skeleton.joints;
    const up = skeleton.headUp;
    const fwd = skeleton.headForward;
    const r = SKELETON.headRadius;

    const cx = head.x + up.x * 3;
    const cy = head.y + up.y * 3;
    const half = Math.sqrt(r * r - 9);

    const frontX = cx + fwd.x * half;
    const frontY = cy + fwd.y * half;
    const backX = cx - fwd.x * half;
    const backY = cy - fwd.y * half;

    ctx.strokeStyle = style.accent;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(frontX, frontY);
    ctx.lineTo(backX, backY);
    ctx.stroke();

    // Ekor ikat kepala, mengarah ke belakang kepala dan sedikit jatuh ke bawah.
    const wave = Math.sin(frame * 0.18);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(backX, backY);
    ctx.lineTo(backX - fwd.x * 14, backY - fwd.y * 14 + 4 + wave * 3);
    ctx.moveTo(backX, backY);
    ctx.lineTo(backX - fwd.x * 10, backY - fwd.y * 10 + 10 + wave * 2);
    ctx.stroke();

    ctx.lineWidth = SKELETON.lineWidth;
  }
}
