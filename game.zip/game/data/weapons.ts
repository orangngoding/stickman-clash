// Jangkauan hitbox senjata dalam piksel dari badan (GDD Bagian 9).
// Tampilan senjata digambar di M6.

export const WEAPONS: Record<string, { reach: number }> = {
  fists: { reach: 60 },
  daggers: { reach: 70 },
  sword: { reach: 95 },
  spear: { reach: 130 },
};
