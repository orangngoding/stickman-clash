import Link from "next/link";

// Mode permainan sesuai GDD Bagian 10. Semuanya dinonaktifkan sampai milestone terkait selesai.
const MODES = [
  { label: "Campaign", milestone: "M8" },
  { label: "Versus CPU", milestone: "M7" },
  { label: "Survival", milestone: "M8" },
  { label: "Pengaturan", milestone: "M10" },
  { label: "Cara Bermain", milestone: "M10" },
] as const;

export default function Home() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-10 px-6 py-12">
      <header className="text-center">
        <h1 className="font-display text-5xl tracking-wide text-cyan-400 sm:text-7xl">
          STICKMAN <span className="text-orange-400">CLASH</span>
        </h1>
        <p className="mt-3 text-sm text-slate-400 sm:text-base">
          Game fighting 2D bergaya stickman. Projek Berpikir Komputasional, SV IPB University.
        </p>
      </header>

      <nav aria-label="Menu utama" className="flex w-full max-w-sm flex-col gap-3">
        <Link
          href="/play"
          className="rounded-md bg-cyan-500 px-5 py-3 text-center font-display text-lg text-slate-950 transition hover:bg-cyan-300"
        >
          Versus 2 Pemain
        </Link>
        <p className="-mt-1 text-center text-xs text-slate-500">
          Best of 3, Blade lawan Brawler. Pilih karakter tersedia di M6.
        </p>

        {MODES.map((mode) => (
          <button
            key={mode.label}
            type="button"
            disabled
            className="flex items-center justify-between rounded-md border border-slate-700 px-5 py-3 text-left font-display text-lg text-slate-500"
          >
            <span>{mode.label}</span>
            <span className="text-xs text-slate-600">tersedia di {mode.milestone}</span>
          </button>
        ))}
      </nav>
    </main>
  );
}
